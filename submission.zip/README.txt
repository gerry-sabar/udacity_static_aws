1. Project CloudFront endpoint URL : http://d2zn4oydco4gv3.cloudfront.net/index.html
2. screenshot files are located in screenshot folder
3. Assignment detail along with screenshot is provided in submission.pdf file
